import React, { useEffect, useState, useRef } from 'react'
import './App.css'
import { initMock, listWithdrawals, getWithdrawal, createWithdrawal } from './api/mockApi'

type Tab = 'list' | 'detail' | 'create'

function App() {
  const [selectedTab, setSelectedTab] = useState<Tab>('list')
  const [selectedId, setSelectedId] = useState<string | null>(null)

  useEffect(() => {
    initMock()
  }, [])

  return (
    <div className="app">
      

      <header className="header">
        <h1>การเบิกถอนเงิน</h1>
        <div className="header-actions">
          <nav className="topnav" role="navigation" aria-label="Main navigation">
      
          </nav>
          <button
            className="create-btn"
            onClick={() => setSelectedTab('create')}
            aria-label="สร้างคำขอใหม่"
            title="สร้างคำขอเบิกถอนใหม่"
          >
            +
          </button>
        </div>
      </header>

      <main className="container layout">
          {selectedTab === 'detail' && selectedId ? (
            <div className="main">
              <DetailPage
                id={selectedId}
                onBack={() => {
                  setSelectedTab('list')
                  setSelectedId(null)
                }}
              />
            </div>
          ) : (
            <div className="main">
              <ListPage
                onOpen={(id) => {
                  setSelectedId(id)
                  setSelectedTab('detail')
                }}
              />
            </div>
          )}

      </main>

      {selectedTab === 'create' && (
        <div
          className="modal-backdrop"
          role="dialog"
          aria-modal="true"
          onClick={() => setSelectedTab('list')}
        >
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <CreatePage
              onCreated={(id) => {
                setSelectedId(id)
                setSelectedTab('detail')
              }}
              onCancel={() => setSelectedTab('list')}
            />
          </div>
        </div>
      )}
    </div>
  )
}

// Helper: format a numeric value (string or number) as Thai Baht
function formatCurrency(value: string | number | undefined) {
  if (value == null) return ''
  let num: number
  if (typeof value === 'number') num = value
  else {
    // remove commas and non-numeric except dot and minus
    const cleaned = String(value).replace(/[^0-9.-]+/g, '')
    num = parseFloat(cleaned)
  }
  if (Number.isNaN(num)) return String(value)
  return new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(num)
}

function ListPage({ onOpen }: { onOpen: (id: string) => void }) {
  const [items, setItems] = useState<any[]>([])
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')

  useEffect(() => {
    const data = listWithdrawals()
    setItems(data)
  }, [])

  const filtered = items.filter((it) => {
    if (status && it.status !== status) return false
    if (!q) return true
    const s = q.toLowerCase()
    return (
      it.name.toLowerCase().includes(s) ||
      it.txId?.toLowerCase().includes(s) ||
      it.id.toLowerCase().includes(s)
    )
  })

  return (
    <div>
      <div className="controls">
        <input aria-label="ค้นหา" placeholder="ค้นหา ชื่อ/tx id/รายการ" value={q} onChange={(e) => setQ(e.target.value)} />
        <select id="filterStatus" title="กรองสถานะ" aria-label="กรองตามสถานะ" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">สถานะทั้งหมด</option>
          <option value="pending">รออนุมัติ</option>
          <option value="approved">อนุมัติ</option>
          <option value="rejected">ปฏิเสธ</option>
        </select>
      </div>

      <div className="table-wrapper">
        <table className="table">
        <thead>
          <tr>
            <th>TX ID</th>
            <th>ชื่อ</th>
            <th>รายละเอียด</th>
            <th>จำนวน</th>
            <th>สถานะ</th>
            <th>วันที่</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((it) => (
              <tr key={it.id} onClick={() => onOpen(it.id)} className="clickable">
              <td>{it.txId}</td>
              <td>{it.name}</td>
              <td>{(it.purpose && String(it.purpose).trim()) || (it.details && String(it.details).trim()) ? ((it.purpose && String(it.purpose).trim()) || (it.details && String(it.details).trim())) : '-'}</td>
              <td>{formatCurrency(it.amount)}</td>
              <td>
                <StatusBadge status={it.status} />
              </td>
              <td>{new Date(it.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
        </table>
      </div>
    </div>
  )
}

function StatusPage({ onOpen }: { onOpen: (id: string) => void }) {
  const data = listWithdrawals()
  const [q, setQ] = useState('')
  const [statusFilter, setStatusFilter] = useState('')

  const filtered = React.useMemo(() => {
    const s = q.trim().toLowerCase()
    return data.filter((d) => {
      if (statusFilter && d.status !== statusFilter) return false
      if (!s) return true
      return (
        d.name.toLowerCase().includes(s) ||
        d.txId?.toLowerCase().includes(s) ||
        d.id.toLowerCase().includes(s)
      )
    })
  }, [data, q, statusFilter])

  return (
    <div className="status-page">
      <h2>สถานะการถอนเงิน</h2>
      <div className="controls">
        <input aria-label="ค้นหา สถานะ" placeholder="ค้นหา ชื่อ/tx id/รายการ" value={q} onChange={(e) => setQ(e.target.value)} />
        <select id="statusFilterStatusPage" aria-label="กรองสถานะ" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">ทั้งหมด</option>
          <option value="pending">รออนุมัติ</option>
          <option value="approved">อนุมัติ</option>
          <option value="rejected">ปฏิเสธ</option>
        </select>
      </div>

      <table className="table">
        <thead>
          <tr>
            <th>TX ID</th>
            <th>ชื่อ</th>
            <th>รายละเอียด</th>
            <th>จำนวน</th>
            <th>สถานะ</th>
            <th>วันที่</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((it) => (
              <tr key={it.id} onClick={() => onOpen(it.id)} className="clickable">
              <td>{it.txId}</td>
              <td>{it.name}</td>
              <td>{(it.purpose && String(it.purpose).trim()) || (it.details && String(it.details).trim()) ? ((it.purpose && String(it.purpose).trim()) || (it.details && String(it.details).trim())) : '-'}</td>
              <td>{formatCurrency(it.amount)}</td>
              <td><StatusBadge status={it.status} /></td>
              <td>{new Date(it.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function CreatePage({ onCreated, onCancel }: { onCreated: (id: string) => void; onCancel?: () => void }) {
  const [name, setName] = useState('')
  const [amount, setAmount] = useState('')
  const [purpose, setPurpose] = useState('')
  const [files, setFiles] = useState<File[]>([])
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [previews, setPreviews] = useState<{ name: string; url: string; type: string }[]>([])


  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onCancel && onCancel()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onCancel])

  function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const list = e.target.files
    if (!list) return
    const arr = Array.from(list)
    setFiles((cur) => [...cur, ...arr])
  }

  useEffect(() => {
    const p = files.map((f) => ({ name: f.name, url: URL.createObjectURL(f), type: f.type }))
    setPreviews(p)
    return () => {
      p.forEach((pp) => URL.revokeObjectURL(pp.url))
    }
  }, [files])

  function removeFile(index: number) {
    const toRemove = previews[index]
    if (toRemove) URL.revokeObjectURL(toRemove.url)
    setFiles((cur) => cur.filter((_, i) => i !== index))
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name || !amount) return alert('กรุณากรอกชื่อและจำนวน')
    const amountClean = amount.toString().replace(/,/g, '')
    const w = createWithdrawal({ name, amount: amountClean, purpose }, files)
    onCreated(w.id)
    setName('')
    setAmount('')
    setPurpose('')
  }

  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>ฟอร์มส่งคำขอเบิกถอน</h2>
        <div>
          <button type="button" className="secondary small" onClick={() => onCancel && onCancel()} aria-label="ปิด">
            ปิด
          </button>
        </div>
      </div>

      <form className="form" onSubmit={onSubmit}>
        <label htmlFor="name">ชื่อผู้ขอ</label>
        <input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="ชื่อ" />

        <label htmlFor="purpose">รายละเอียด/เหตุผลการเบิกถอน</label>
        <textarea id="purpose" value={purpose} onChange={(e) => setPurpose(e.target.value)} placeholder="เช่น ค่าของสำนักงาน, ค่าซ่อม" />

        <label htmlFor="amount">จำนวน (บาท)</label>
        <div className="input-with-icon">
          <input
            id="amount"
            type="text"
            inputMode="decimal"
            value={amount}
            onChange={(e) => {
              let v = e.target.value
              v = v.replace(/[^0-9.]/g, '')
              const parts = v.split('.')
              if (parts.length > 2) v = parts[0] + '.' + parts.slice(1).join('')
              setAmount(v)
            }}
            onFocus={() => {
              const cleaned = amount.replace(/,/g, '')
              setAmount(cleaned)
            }}
            onBlur={() => {
              const num = parseFloat((amount || '').toString().replace(/,/g, ''))
              if (Number.isNaN(num)) {
                setAmount('')
              } else {
                setAmount(num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }))
              }
            }}
            placeholder="ตัวอย่าง: 1200.00"
          />
          <button type="button" className="icon-btn" onClick={() => fileInputRef.current && fileInputRef.current.click()} aria-label="เลือกรูปหรือวิดีโอ">
            <img src="/uploadimage.png" className="input-icon" alt="เลือกรูปหรือวิดีโอ" />
          </button>
          <input 
            ref={fileInputRef} 
            id="files" 
            type="file" 
            accept="image/*,video/*" 
            multiple 
            onChange={onFileChange} 
            style={{ display: 'none' }} 
            tabIndex={-1} 
            aria-label="Upload images or videos"
          />
        </div>

        {previews.length ? (
          <div className="previews" style={{ marginTop: 12 }}>
            {previews.map((p, idx) => (
              <div className="preview" key={p.url}>
                <button type="button" className="preview-remove" aria-label={`ลบ ${p.name}`} onClick={() => removeFile(idx)}>×</button>
                {p.type.startsWith('image') ? (
                  <img src={p.url} alt={p.name} style={{ maxWidth: 320, borderRadius: 8 }} />
                ) : (
                  <video src={p.url} style={{ maxWidth: 320, borderRadius: 8 }} controls />
                )}
              </div>
            ))}
          </div>
        ) : null}

        <div className="actions">
          <button type="submit">ส่งคำขอ</button>
          <button type="button" className="secondary" onClick={() => { setName(''); setAmount(''); setPurpose(''); setFiles([]) }}>
            รีเซ็ต
          </button>
        </div>
      </form>
    </div>
  )
}

function DetailPage({ id, onBack }: { id: string; onBack: () => void }) {
  const [item, setItem] = useState<any | null>(null)

  useEffect(() => {
    const it = getWithdrawal(id)
    setItem(it)
  }, [id])

  if (!item) return <div>ไม่พบรายการ</div>
  const statusLabels: Record<string, string> = {
    pending: 'รออนุมัติ',
    approved: 'อนุมัติ',
    rejected: 'ปฏิเสธ'
  }

  return (
    <div className="card">
      <button onClick={onBack} className="secondary small">
        กลับ
      </button>
      <h2>รายละเอียดรายการ</h2>
      <p>
        <strong>Tx:</strong> {item.txId}
      </p>
      <p>
        <strong>ชื่อ:</strong> {item.name}
      </p>
      {(item.details || item.purpose) ? (
        <p>
          <strong>รายละเอียด:</strong> {item.details || item.purpose}
        </p>
      ) : null}
      <p>
        <strong>จำนวน:</strong> {formatCurrency(item.amount)}
      </p>
      
      <p>
        <strong>สถานะ:</strong> <StatusBadge status={item.status} />
      </p>
      <p>
        <strong>วันที่:</strong> {new Date(item.createdAt).toLocaleString()}
      </p>


      <div className="attachments">
        {item.attachments.map((a: any) => (
          <AttachmentView key={a.id} a={a} />
        ))}
      </div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    pending: 'รออนุมัติ',
    approved: 'อนุมัติ',
    rejected: 'ปฏิเสธ'
  }
  const text = labels[status] ?? status
  return <span className={`badge ${status}`} aria-label={text}>{text}</span>
}

function AttachmentView({ a }: { a: any }) {
  if (a.type.startsWith('image/')) {
    return <img src={a.url} alt={a.name} className="thumb" />
  }
  if (a.type.startsWith('video/')) {
    return (
      <video controls className="thumb">
        <source src={a.url} type={a.type} />
      </video>
    )
  }
  return <a href={a.url}>{a.name}</a>
}

export default App
