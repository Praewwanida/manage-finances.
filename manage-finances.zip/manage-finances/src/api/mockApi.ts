// Seed data inlined from mockData.ts (merged for simpler packaging)

type Attachment = {
  id: string
  name: string
  type: string
  url: string
}

type HistoryItem = {
  status: string
  at: string
  note?: string
}

type Withdrawal = {
  id: string
  txId: string
  name: string
  amount: string
  purpose?: string
  details?: string
  status: string
  createdAt: string
  attachments: Attachment[]
  history: HistoryItem[]
}

const MOCK_WITHDRAWALS: Withdrawal[] = [

  {
    id: 'a1b2c3d',
    txId: 'TX000001',
    name: 'ชื่อ-นามสกุล 01',
    amount: '1,200',
    details: 'ค่าน้ำมันสำหรับเดินทางไปประชุมกับลูกค้า',
    status: 'pending',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    attachments: [
      { id: 'att1', name: 'receipt-ex1.png', type: 'image/png', url: '/receipt-ex1.png' }
    ],
    history: [{ status: 'pending', at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), note: 'สร้างคำขอ' }]
  },
  {
    id: 'd4e5f6g',
    txId: 'TX000002',
    name: 'ชื่อ-นามสกุล 02',
    amount: '1,500',
    details: 'ค่าอาหารสำหรับการประชุม',
    status: 'approved',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    attachments: [
      { id: 'att2', name: 'receipt-ex2.png', type: 'image/png', url: '/receipt-ex2.png' }
    ],
    history: [
      { status: 'pending', at: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(), note: 'สร้างคำขอ' },
      { status: 'approved', at: new Date(Date.now() - 1000 * 60 * 60 * 47).toISOString(), note: 'อนุมัติโดยผู้จัดการ' }
    ]
  },
  {
    id: 'h7i8j9k',
    txId: 'TX000003',
    name: 'ชื่อ-นามสกุล 03 ',
    amount: '3,500',
    details: 'ค่าที่พัก',
    status: 'rejected',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    attachments: [
      { id: 'att3', name: 'receipt-ex3.png', type: 'image/png', url: '/receipt-ex3.png' }
    ],
    history: [
      { status: 'pending', at: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(), note: 'สร้างคำขอ' },
      { status: 'rejected', at: new Date(Date.now() - 1000 * 60 * 60 * 71).toISOString(), note: 'เอกสารไม่ครบ' }
    ]
  }
]

const STORE_KEY = 'mock_withdrawals_v1'

function id() {
  return Math.random().toString(36).slice(2, 9)
}

function saveAll(items: Withdrawal[]) {
  localStorage.setItem(STORE_KEY, JSON.stringify(items))
}

function loadAll(): Withdrawal[] {
  const raw = localStorage.getItem(STORE_KEY)
  if (!raw) return []
  try {
    return JSON.parse(raw) as Withdrawal[]
  } catch {
    return []
  }
}

export function initMock() {
  // In development, clear stored mock data so edits to the committed
  // `MOCK_WITHDRAWALS` are reflected immediately without manually clearing
  // localStorage. This is safe for local dev only.
  if (typeof import.meta !== 'undefined' && (import.meta as any).env && (import.meta as any).env.DEV) {
    try {
      localStorage.removeItem(STORE_KEY)
      // eslint-disable-next-line no-console
      console.info('mockApi: cleared stored mock data (dev mode) to apply seed changes')
    } catch (e) {
      // ignore
    }
  }
  const cur = loadAll()
  // If there is no stored data, seed from the committed mock data file
  if (cur.length === 0) {
    const mapped = MOCK_WITHDRAWALS.map((w) => ({ ...w }))
    saveAll(mapped)
    return
  }

  // If stored data exists, merge missing fields from the seeded mock data
  // This ensures existing dev installs get new fields like `purpose`/`details`.
  const updated = cur.slice()
  for (const seed of MOCK_WITHDRAWALS) {
    const idx = updated.findIndex((i) => i.txId === seed.txId)
    if (idx === -1) {
      // seed not present — add it
      updated.unshift({ ...seed })
    } else {
      const existing = updated[idx]

      // Decide attachments: prefer existing attachments unless they look external/remote.
      // If existing attachments exist but their URLs are not local (don't start with '/'),
      // replace them with the seeded local attachments. This helps switch from remote
      // picsum URLs to project `public/` files without clearing localStorage.
      let attachments = existing.attachments && existing.attachments.length ? existing.attachments : seed.attachments
      if (
        existing.attachments &&
        existing.attachments.length &&
        seed.attachments &&
        seed.attachments.length
      ) {
        const allExistingAreRemote = existing.attachments.every((a) => !a.url.startsWith('/'))
        if (allExistingAreRemote) {
          attachments = seed.attachments
        }
      }

      updated[idx] = {
        ...existing,
        name: existing.name || seed.name,
        amount: existing.amount || seed.amount,
        details: existing.details && String(existing.details).trim() ? existing.details : seed.details,
        attachments,
        history: existing.history && existing.history.length ? existing.history : seed.history
      }
    }
  }
  saveAll(updated)
}

export function listWithdrawals(): Withdrawal[] {
  return loadAll().sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
}

export function getWithdrawal(idq: string): Withdrawal | null {
  return loadAll().find((i) => i.id === idq) ?? null
}

export function createWithdrawal(data: { name: string; amount: string; txId?: string; purpose?: string; details?: string }, files: File[] = []) {
  const items = loadAll()
  const createdAt = new Date().toISOString()
  const attachments: Attachment[] = files.map((f) => {
    const blobUrl = URL.createObjectURL(f)
    return { id: id(), name: f.name, type: f.type, url: blobUrl }
  })
  // Generate a readable, reasonably unique TX id when not provided
  const generatedTx = data.txId || 'TX' + String(Date.now()).slice(-6)
  const w: Withdrawal = {
    id: id(),
    txId: generatedTx,
    name: data.name,
    amount: data.amount,
    details: data.purpose ?? data.details,
    status: 'pending',
    createdAt,
    attachments,
    history: [{ status: 'pending', at: createdAt, note: 'สร้างคำขอ' }]
  }
  items.unshift(w)
  saveAll(items)
  return w
}

export function addAttachment(withdrawalId: string, file: File) {
  const items = loadAll()
  const w = items.find((i) => i.id === withdrawalId)
  if (!w) throw new Error('not found')
  const a: Attachment = { id: id(), name: file.name, type: file.type, url: URL.createObjectURL(file) }
  w.attachments.push(a)
  saveAll(items)
  return a
}
